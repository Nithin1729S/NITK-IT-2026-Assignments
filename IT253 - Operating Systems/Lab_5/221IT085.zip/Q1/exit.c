#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
    printf("Hello\n");
    exit(1);
    printf("Bye");
    return 0;
}



